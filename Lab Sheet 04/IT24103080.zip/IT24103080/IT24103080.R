setwd("C:\\Users\\IT24103080\\Desktop\\IT24103080")
getwd()

#1. Import the dataset (’Exercise.txt’) into R and store it in a data frame called
#”branch data”.

branch_data <- read.table("Exercise.txt", header=TRUE, sep=",")
head(branch_data)

#2. Identify the variable type and scale of measurement for each variable.

str(branch_data)

#3. Obtain boxplot for sales and interpret the shape of the sales distribution.

boxplot(branch_data$Sales_X1, main="Sales", ylab="sales")

#4. Calculate the five number summary and IQR for advertising variable.

fivenum(branch_data$Advertising_X2)
IQR(branch_data$Advertising_X2)

#5. Write an R function to find the outliers in a numeric vector and check for outliers
#in years variables.

find_outliers <- function(x){
  q1 <- quantile(x,0.25)
  q3 <- quantile(x,0.75)
  IQR_value <- q3 - q1
  lower <- q1-1.5*IQR_value
  upper <- q3+1.5*IQR_value
  outliers <- x[x<lower | x>upper]
  return(outliers)
}

find_outliers(branch_data$Years_X3)
